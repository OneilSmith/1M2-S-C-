namespace JsonProductos
{
    public partial class Form1 : Form
    {
        private List<Producto> productos = new List<Producto>();
        public Form1()
        {
            InitializeComponent();
            productos = JSON.LeerDatos();
        }

        private void AgregarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nombre del producto:", "Agregar Producto", "");
                if (string.IsNullOrWhiteSpace(nombre))
                {
                    MessageBox.Show("El nombre no puede estar vac�o.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string precioTexto = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el precio del producto:", "Agregar Producto", "0");
                if (!decimal.TryParse(precioTexto, out decimal precio) || precio <= 0)
                {
                    MessageBox.Show("El precio debe ser un n�mero positivo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string cantidadTexto = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la cantidad del producto:", "Agregar Producto", "0");
                if (!int.TryParse(cantidadTexto, out int cantidad) || cantidad < 0)
                {
                    MessageBox.Show("La cantidad debe ser un n�mero entero no negativo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var productos = JSON.LeerDatos();

                var nuevoProducto = new Producto(productos.Count + 1, nombre, precio, cantidad);
                productos.Add(nuevoProducto);

                JSON.GuardarDatos(productos);

                MessageBox.Show("Producto agregado correctamente.", "�xito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void VerDatosProducto_Click(object sender, EventArgs e)
        {
            try
            {
                var productos = JSON.LeerDatos();

                if (productos.Count == 0)
                {
                    MessageBox.Show("No hay productos guardados.", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string mensaje = "Productos Guardados:\n\n";
                foreach (var producto in productos)
                {
                    mensaje += $"ID: {producto.Id}, Nombre: {producto.Nombre}, Precio: {producto.Precio:C}, Cantidad: {producto.Cantidad}\n";
                }
                MessageBox.Show(mensaje, "Productos Guardados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al leer los datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            var confirmacion = MessageBox.Show("�Est�s seguro de que deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmacion == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }


}

    


