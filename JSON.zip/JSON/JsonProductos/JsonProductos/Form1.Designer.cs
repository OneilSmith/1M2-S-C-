﻿namespace JsonProductos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label1 = new Label();
            AgregarProducto = new Button();
            VerDatosProducto = new Button();
            Salir = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonShadow;
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(762, 80);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(249, 23);
            label1.Name = "label1";
            label1.Size = new Size(220, 40);
            label1.TabIndex = 0;
            label1.Text = "Productos";
            // 
            // AgregarProducto
            // 
            AgregarProducto.BackColor = SystemColors.ActiveCaption;
            AgregarProducto.Location = new Point(261, 126);
            AgregarProducto.Name = "AgregarProducto";
            AgregarProducto.Size = new Size(247, 65);
            AgregarProducto.TabIndex = 2;
            AgregarProducto.Text = "Agregar";
            AgregarProducto.UseVisualStyleBackColor = false;
            AgregarProducto.Click += AgregarProducto_Click;
            // 
            // VerDatosProducto
            // 
            VerDatosProducto.BackColor = SystemColors.ActiveCaption;
            VerDatosProducto.Location = new Point(274, 197);
            VerDatosProducto.Name = "VerDatosProducto";
            VerDatosProducto.Size = new Size(216, 64);
            VerDatosProducto.TabIndex = 4;
            VerDatosProducto.Text = "VerDatos";
            VerDatosProducto.UseVisualStyleBackColor = false;
            VerDatosProducto.Click += VerDatosProducto_Click;
            // 
            // Salir
            // 
            Salir.BackColor = SystemColors.ActiveCaption;
            Salir.Location = new Point(323, 267);
            Salir.Name = "Salir";
            Salir.Size = new Size(118, 58);
            Salir.TabIndex = 5;
            Salir.Text = "Salir";
            Salir.UseVisualStyleBackColor = false;
            Salir.Click += Salir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Salir);
            Controls.Add(VerDatosProducto);
            Controls.Add(AgregarProducto);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private Button AgregarProducto;
        private Button VerDatosProducto;
        private Button Salir;
    }
}
