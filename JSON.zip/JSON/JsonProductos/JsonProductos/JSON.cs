﻿using System;
using JsonProductos;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

public static class JSON
{
    private static string filePath = "productos.json";
    public static void GuardarDatos(List<Producto> productos)
    {
        var jsonData = JsonSerializer.Serialize(productos, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, jsonData);
    }
    public static List<Producto> LeerDatos()
    {
        if (!File.Exists(filePath))
        {
            return new List<Producto>();
        }

        var jsonData = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<List<Producto>>(jsonData);
    }
}
