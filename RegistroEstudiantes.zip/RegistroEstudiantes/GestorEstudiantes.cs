﻿using System;
using System.Collections.Generic;

namespace RegistroEstudiantes
{
    public class GestorEstudiantes
    {
        private List<Estudiante> estudiantes;

        public GestorEstudiantes()
        {
            estudiantes = new List<Estudiante>();
        }

        // Método para obtener todos los estudiantes
        public List<Estudiante> ObtenerEstudiantes()
        {
            return estudiantes;
        }

        // Método para agregar un nuevo estudiante
        public void AgregarEstudiante(Estudiante estudiante)
        {
            if (estudiante == null)
            {
                throw new ArgumentNullException(nameof(estudiante), "El estudiante no puede ser nulo.");
            }

            if (string.IsNullOrWhiteSpace(estudiante.Nombre))
            {
                throw new ArgumentException("El nombre del estudiante es obligatorio.");
            }

            if (estudiante.Edad < 5 || estudiante.Edad > 25)
            {
                throw new ArgumentOutOfRangeException(nameof(estudiante.Edad), "La edad debe estar entre 5 y 25 años.");
            }

            estudiantes.Add(estudiante);
        }

        // Método para editar un estudiante existente
        public void EditarEstudiante(int index, Estudiante estudiante)
        {
            if (index >= 0 && index < estudiantes.Count)
            {
                estudiantes[index] = estudiante;
            }
            else
            {
                throw new ArgumentOutOfRangeException(nameof(index), "El índice está fuera de rango.");
            }
        }


        // Método para eliminar un estudiante
        public void EliminarEstudiante(int index)
        {
            if (index >= 0 && index < estudiantes.Count)
            {
                estudiantes.RemoveAt(index);
            }
            else
            {
                throw new ArgumentOutOfRangeException(nameof(index), "El índice está fuera de rango.");
            }
        }

        // Método para cargar datos iniciales
        public void CargarDatosIniciales()
        {
            estudiantes.Add(new Estudiante("Juan Pérez", 15, "Primero", "Becado"));
            estudiantes.Add(new Estudiante("María López", 17, "Segundo", "Regular"));
            estudiantes.Add(new Estudiante("Carlos Díaz", 16, "Tercero", "Becado"));
        }
    }
}
