﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistroEstudiantes
{
    public partial class FormEstudiante : Form
    {
        public Estudiante Estudiante { get; set; }

        public FormEstudiante()
        {
            InitializeComponent();
            estudiante = new GestorEstudiantes();
            gestor.CargarDatosIniciales();
            ActualizarTabla();
        }

       


        private bool EsNombreValido(string nombre)
        {
            // Permite solo letras (incluye tildes) y espacios
            return System.Text.RegularExpressions.Regex.IsMatch(nombre, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$");
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            // Si el diálogo fue cancelado, no validar
            if (DialogResult != DialogResult.OK) return;

            // Validar que el nombre no esté vacío
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El nombre no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNombre.Focus();
                e.Cancel = true; // Cancela el cierre del formulario
                return;
            }

            // Validar que el nombre tenga un formato válido
            if (!EsNombreValido(txtNombre.Text))
            {
                MessageBox.Show("El nombre solo debe contener letras y espacios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNombre.Focus();
                e.Cancel = true; // Cancela el cierre del formulario
                return;
            }
        }


        private bool ValidarDatos()
        {
            // Verificar que el campo de nombre no esté vacío
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El nombre es obligatorio.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            // Verificar que la edad sea un número válido y esté en el rango permitido
            if (!int.TryParse(txtEdad.Text, out int edad) || edad < 5 || edad > 25)
            {
                MessageBox.Show("La edad debe ser un número entre 5 y 25.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            // Verificar que se haya seleccionado un grado
            if (string.IsNullOrWhiteSpace(cmbGrado.SelectedItem?.ToString()))
            {
                MessageBox.Show("Debe seleccionar un grado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            // Verificar que se haya seleccionado un estado
            if (string.IsNullOrWhiteSpace(cmbEstado.SelectedItem?.ToString()))
            {
                MessageBox.Show("Debe seleccionar un estado (Becado o Regular).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true; // Todos los datos son válidos
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (ValidarDatos())
            {
                // Crear un nuevo objeto Estudiante con los datos validados
                Estudiante = new Estudiante(
                    txtNombre.Text,
                    int.Parse(txtEdad.Text),
                    cmbGrado.SelectedItem.ToString(),
                    cmbEstado.SelectedItem.ToString()
                );

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void numericEdad_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
