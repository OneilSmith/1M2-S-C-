﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistroEstudiantes
{
    public partial class Form1 : Form
    {
        private List<Estudiante> estudiantes;

        public Form1()
        {
            InitializeComponent();
            estudiantes = new List<Estudiante>(); // Inicializa la lista
        }

        private GestorEstudiantes gestor;

        private void Form1_Load(object sender, EventArgs e)
        {
            gestor = new GestorEstudiantes();
            gestor.CargarDatosIniciales(); // Carga los datos iniciales
            ActualizarTabla();
        }


        private void ActualizarTabla()
        {
            dataGridViewEstudiantes.DataSource = null;
            dataGridViewEstudiantes.DataSource = gestor.ObtenerEstudiantes();
        }

        private void btnEstadisticas_Click(object sender, EventArgs e)
        {
            var estudiantes = gestor.ObtenerEstudiantes();
            var promedioEdad = Estadisticas.CalcularPromedioEdad(estudiantes);
            var totalPorGrado = Estadisticas.TotalPorGrado(estudiantes);
            var porcentajeBecados = Estadisticas.CalcularPorcentajeBecados(estudiantes);

            var formEstadisticas = new FormEstadisticas
            {
                PromedioEdad = promedioEdad,
                TotalPorGrado = totalPorGrado,
                PorcentajeBecados = porcentajeBecados
            };

            formEstadisticas.ShowDialog();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            FormEstudiante formEstudiante = new FormEstudiante();

            if (formEstudiante.ShowDialog() == DialogResult.OK)
            {
                if (formEstudiante.Estudiante == null)
                {
                    MessageBox.Show("El estudiante no se ha creado correctamente.");
                    return;
                }

                estudiantes.Add(formEstudiante.Estudiante); // Agrega el estudiante a la lista
                ActualizarDataGridView(); // Actualiza la tabla
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                // Verificar que haya una fila seleccionada
                if (dataGridViewEstudiantes.CurrentRow == null)
                {
                    MessageBox.Show("Por favor, seleccione un estudiante para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Obtener el índice del estudiante seleccionado
                int index = dataGridViewEstudiantes.CurrentRow.Index;

                // Validar el índice y obtener los datos actuales del estudiante
                var estudiantes = gestor.ObtenerEstudiantes();
                if (index < 0 || index >= estudiantes.Count)
                {
                    MessageBox.Show("El estudiante seleccionado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Obtener los datos actuales del estudiante
                var estudianteActual = estudiantes[index];

                // Crear el formulario de edición y pasar los datos actuales
                var formEstudiante = new FormEstudiante
                {
                    Estudiante = new Estudiante(
                        estudianteActual.Nombre,
                        estudianteActual.Edad,
                        estudianteActual.Grado,
                        estudianteActual.Estado
                    )
                };

                // Mostrar el formulario de edición
                if (formEstudiante.ShowDialog() == DialogResult.OK)
                {
                    // Actualizar los datos del estudiante
                    gestor.EditarEstudiante(index, formEstudiante.Estudiante);

                    // Actualizar la tabla
                    ActualizarTabla();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Se produjo un error al editar el estudiante: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                // Verificar si hay una fila seleccionada
                if (dataGridViewEstudiantes.CurrentRow == null)
                {
                    MessageBox.Show("Por favor, seleccione un estudiante para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Confirmar la eliminación con el usuario
                var confirmResult = MessageBox.Show(
                    "¿Está seguro de que desea eliminar este estudiante?",
                    "Confirmar eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {
                    // Obtener el índice del estudiante seleccionado
                    int index = dataGridViewEstudiantes.CurrentRow.Index;

                    // Validar el índice
                    var estudiantes = gestor.ObtenerEstudiantes();
                    if (index < 0 || index >= estudiantes.Count)
                    {
                        MessageBox.Show("El estudiante seleccionado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Eliminar el estudiante del gestor
                    gestor.EliminarEstudiante(index);

                    // Actualizar el DataGridView
                    ActualizarTabla();

                    MessageBox.Show("Estudiante eliminado con éxito.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Se produjo un error al eliminar el estudiante: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ActualizarDataGridView()
        {
            dataGridViewEstudiantes.DataSource = null; // Limpia la fuente anterior
            dataGridViewEstudiantes.DataSource = estudiantes; // Asigna la lista actualizada
        }

        private void dataGridViewEstudiantes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtEdad_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int edad;
            if (int.TryParse(txtEdad.Text, out edad) && edad > 0)
            {
                // Usa la edad para tu lógica
            }
            else
            {
                MessageBox.Show("Por favor, introduce una edad válida.");
            }


        }
    }
}
